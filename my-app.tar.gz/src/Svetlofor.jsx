import React, { useState , useEffect } from "react";
import style from'./Svetlofor.module.css'
const Svetlofor = (props)=>{

const [timer,setTimer] = useState(0);
const [vkl,setVkl] = useState(false);

useEffect(() => {
    const interval = setInterval(async () => {
      const response = await fetch(`http://66.135.12.132:3000/timers/${props.dd.id}`);
      const data = await response.json();
      setTimer(data.time);
      console.log(data.limit)
    }, 200);

    return () => {
      clearInterval(interval);
    };
  }, [props.dd.id]);

    return(
        <div onClick={()=>{props.takeId(props.dd.id); setVkl(!vkl)}} className={vkl ? style.blockOn: style.block}>
            <div className={style.ulica2}>{props.dd.ulica2}</div>

          {props.dd.type === 2
          ? (
          <>
            <div className={timer<=props.dd.leftGreen ? style.firstGreen : style.first}>
              {
               timer<=props.dd.leftGreen
               ? props.dd.leftGreen - timer
               : props.dd.red + props.dd.green - timer
              }
            </div> 

            <div className={timer < props.dd.red ? style.first : style.firstGreen}>
              {timer<props.dd.red ? props.dd.red - timer : props.dd.red + props.dd.green - timer}
            </div>
         
            <div className={timer <= props.dd.red - (props.dd.rightGreen - props.dd.green) ? style.first : style.firstGreen}>
             {
              timer <= props.dd.red - (props.dd.rightGreen - props.dd.green)
              ? props.dd.red - (props.dd.rightGreen - props.dd.green) - timer
              : props.dd.red + props.dd.green - timer
             }   
            </div>
          </>)
          : <div className={timer < props.dd.red ? style.first : style.firstGreen}>
              {timer<props.dd.red ? props.dd.red - timer : props.dd.red + props.dd.green - timer}
            </div>}
        </div>
    );
}
export default Svetlofor;