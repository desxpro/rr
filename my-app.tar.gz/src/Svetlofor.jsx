import React, { useState , useEffect } from "react";
import style from'./Svetlofor.module.css'
const Svetlofor = (props)=>{

const [timer,setTimer] = useState(0);
const [vkl,setVkl] = useState(false);

useEffect(() => {
  if(vkl)
  {
    const interval = setInterval(async () => {
      const response = await fetch(`http://localhost:3000/timers/${props.dd.id}`);
      const data = await response.json();
      setTimer(data.time);
      console.log('server')
    }, 200);

    return () => {
      clearInterval(interval);
    };
  }
  else 
  {
    const interval = setInterval(
      ()=>{
        if(timer >= props.dd.constanta) setTimer(0);
        else setTimer(p=>p+1);
        console.log('client')
      },1000
    );
    
    return () => {
      clearInterval(interval);
      
    };
  }
    

    
  },[vkl,props.dd.constanta, props.dd.id, timer]);

useEffect(()=>{
      const fun  = async ()=>{
        const response = await fetch(`http://localhost:3000/timers/${props.dd.id}`);
        const data = await response.json();
        setTimer(data.time);
      }
      fun();
      
},[props.dd.id])  
    return(
        <div onClick={()=>{props.takeId(props.dd.id); setVkl(!vkl)}} className={vkl ? style.blockOn: style.block}>
            <div className={style.ulica2}>{props.dd.ulica2}</div>

          {props.dd.type === 2
          ? (
          <>
            <div className={timer<=props.dd.leftGreen ? style.firstGreen : style.first}>
              {
               timer<=props.dd.leftGreen
               ? props.dd.leftGreen - timer
               : props.dd.red + props.dd.green - timer
              }
            </div> 

            <div className={timer < props.dd.red ? style.first : style.firstGreen}>
              {timer<props.dd.red ? props.dd.red - timer : props.dd.red + props.dd.green - timer}
            </div>
         
            <div className={timer <= props.dd.red - (props.dd.rightGreen - props.dd.green) ? style.first : style.firstGreen}>
             {
              timer <= props.dd.red - (props.dd.rightGreen - props.dd.green)
              ? props.dd.red - (props.dd.rightGreen - props.dd.green) - timer
              : props.dd.red + props.dd.green - timer
             }   
            </div>
          </>)
          : <div className={timer < props.dd.red ? style.first : style.firstGreen}>
              {timer<props.dd.red ? props.dd.red - timer : props.dd.red + props.dd.green - timer}
            </div>}
        </div>
    );
}
export default Svetlofor;