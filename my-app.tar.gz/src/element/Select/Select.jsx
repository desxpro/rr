import cls from './Select.module.css'

const Select = (props) =>

{
//  console.log(props.value)
return(
    <div className={cls.block}>
        <select className={cls.select} onChange = {e=>props.onChange(e.target.value)}>
            <option value="default">{props.value}</option>
            <option value={'Пр-Мира'}>Пр-Мира</option>
            <option value={'Пр-Победы'}>Пр-Победы</option>
        </select>
        <button className={cls.btn}>i!</button>
    </div>
)
}
export default Select;