import cls from './Panel.module.css'

const Panel = ({id}) =>
{
    const min = async () => {
        await fetch(`http://66.135.12.132:3000/timers/${id}/min`, { method: 'POST' });
      };
      const plus = async ()=>{
        await fetch(`http://66.135.12.132:3000/timers/${id}/plus`, {method: 'POST'});
      }
      const stop = async ()=>{
        await fetch(`http://66.135.12.132:3000/timers/${id}/stop`, {method: 'POST'});
      }
    return(
        <div className={cls.panel}>
            <button className={cls.btn} onClick={min}>{'<<'}</button>
            <button className={cls.btn} onClick={stop}>{'||'}</button>
            <button className={cls.btn} onClick={plus}>{'>>'}</button>
        </div>
    )
}

export default Panel;