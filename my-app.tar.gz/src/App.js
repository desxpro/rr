
import './App.css';
import Svetlofor from './Svetlofor';
import { useState } from 'react';
import Select from './element/Select/Select';
import Panel from './element/Panel/Panel';
function App() {
  
let prMira = [
// {
//   id: 'prp1',
//   red: 61,
//   green: 33,
//   leftGreen: 20,
//   rightGreen: 47,
//   ulica : 'Пр-Победы',
//   ulica2 : 'Гонча',
// }
  { id : 'prp1', type: 1, red : 34, green : 45, ulica : 'Пр-Победы', ulica2 : 'Гонча'},
  { id : 'prp2', type: 1, red : 34 ,green : 45 ,ulica : 'Пр-Победы' ,ulica2 : 'Мстиславская'},
  { id : 'prp3', type: 1, red : 34, green : 45, ulica : 'Пр-Победы', ulica2 : 'Пятницкая'},
  { id : 'prp4', type: 1, red : 84, green : 27, ulica : 'Пр-Победы', ulica2 : 'Пр-Мира'},
  { id : 'prp5', type: 1, red : 34, green : 45, ulica : 'Пр-Победы', ulica2 : 'Кирпоноса'},
  { id : 'prp6', type: 1, red : 52, green : 27, ulica : 'Пр-Победы', ulica2 : 'Ремесленная'},
  { id : 'prp7', type: 1, red : 37, green : 42, ulica : 'Пр-Победы', ulica2 : 'Хлебопекарская'},
  { id : 'prp8', type: 1, red : 54, green : 30, ulica : 'Пр-Победы', ulica2 : 'Жабинского'}, 

  { id : 'prm1', type: 1, red : 54, green : 14, ulica : 'Пр-Мира', ulica2: 'Преобреженская'},
  { id : 'prm2', type: 1, red : 88, green : 23, ulica : 'Пр-Мира', ulica2: 'Пр-Победы'},
  { id : 'prm3', type: 1, red : 58, green : 21, ulica : 'Пр-Мира', ulica2: 'Киевская'},
  { id : 'prm4', type: 1, red : 56, green : 24, ulica : 'Пр-Мира', ulica2: 'София русая'},
  { id : 'prm5', type: 1, red : 37, green : 35, ulica : 'Пр-Мира', ulica2: 'Котляревского'},
  { id : 'prm6', type: 1, red : 30, green : 33, ulica : 'Пр-Мира', ulica2: 'Не Бабы'},
] 

const [list, setList]  = useState([]);
const [id,setId]       = useState('');
const [sw,setSw]       = useState(false);
const [deful,setdeful] = useState('');

const takeId = (id) =>
{
  setId(id)
  console.log(id)
  if(sw) setSw(false)
  else setSw(true);
}

const filterL = (value) =>
{
  setList(prMira.filter(e=>e.ulica === value))
  setdeful(value)
}
  return (
   <div className='App'>
    {sw ? <Panel id={id}/> : <Select value={deful} onChange={filterL}/>}
    {list.map((elem)=> <Svetlofor dd={elem} key={elem.id} takeId={takeId}/>)}
   </div>
  );
}

export default App;
